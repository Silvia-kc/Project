﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Collections.Specialized.BitVector32;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace CarService_Project
{
    public class SelectRequest
    {
        public void GetAllClientsAndVehicles(SqlConnection connection)
        {
            

            using (connection = new SqlConnection(@"Data Source=DESKTOP-LT689HU\SQLEXPRESS;" +
            "Integrated Security=True;Trust Server Certificate=True;" +
            "Initial Catalog=CarService;"))
            {
                connection.Open();

                string query = @"
                SELECT c.FirstName, c.LastName, v.Brand, v.Model
                FROM Clients c
                JOIN Vehicles v ON c.ClientID = v.ClientID";

                using (SqlCommand cmd = new SqlCommand(query, connection))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Console.WriteLine($"{reader["FirstName"]} {reader["LastName"]} - " +
                                          $"{reader["Brand"]} {reader["Model"]}");
                    }
                }
            }
        }
        public void SearchVehiclesByLicensePlate(SqlConnection connection)
        {
            using (connection = new SqlConnection(@"Data Source=DESKTOP-LT689HU\SQLEXPRESS;" +
            "Integrated Security=True;Trust Server Certificate=True;" +
            "Initial Catalog=CarService;"))
            {
                connection.Open();

                Console.WriteLine("Enter license plate: ");
                string licensePlate = Console.ReadLine();
                string query = @"
                SELECT Brand, Model, YearOfManifacture
                FROM Vehicles WHERE LicensePlate=@licensePlate";

                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@licensePlate", licensePlate);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Console.WriteLine($"{reader["Brand"]} {reader["Model"]} {reader["YearOfManifacture"]}");

                        }
                    }
                }
            }
        }
        public void AllRepairsAboutCertainClient(SqlConnection connection)
        {
            using (connection = new SqlConnection(@"Data Source=DESKTOP-LT689HU\SQLEXPRESS;" +
            "Integrated Security=True;Trust Server Certificate=True;" +
            "Initial Catalog=CarService;"))
            {
                connection.Open();

                Console.WriteLine("Enter client first name: ");
                string firstName = Console.ReadLine();
                Console.WriteLine("Enter client last name: ");
                string lastName = Console.ReadLine();

                string query = @"
                SELECT r.RepairID, r.DateIn, r.DateOut, r.TotalCost, r.RepairType, v.Brand, v.Model
                FROM Repairs r
                JOIN Vehicles v ON r.VehicleID = v.VehicleID
                JOIN Clients c ON v.ClientID = c.ClientID
                WHERE c.FirstName = @firstName AND c.LastName = @lastName";
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@firstName", firstName);
                    cmd.Parameters.AddWithValue("@lastName", lastName);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Console.WriteLine($"Repair ID: {reader["RepairID"]}, " +
                                              $"Car: {reader["Brand"]} {reader["Model"]}, " +
                                              $"Date In: {reader["DateIn"]}, " +
                                              $"Date Out: {reader["DateOut"]}, " +
                                              $"Total Cost: {reader["TotalCost"]} BGN, " +
                                              $"Repair Type: {reader["RepairType"]}");
                        }
                    }
                }
            }
        }
        public void GetRepairsByMechanic(SqlConnection connection)
        {
            using (connection = new SqlConnection(@"Data Source=DESKTOP-LT689HU\SQLEXPRESS;" +
            "Integrated Security=True;Trust Server Certificate=True;" +
            "Initial Catalog=CarService;"))
            {
                connection.Open();

                Console.WriteLine("Enter mechanic first name: ");
                string firstName = Console.ReadLine();
                Console.WriteLine("Enter mechanoic last name: ");
                string lastName = Console.ReadLine();

                string query = @"
                SELECT r.RepairID, r.DateIn, r.DateOut, r.TotalCost, r.RepairType, v.Brand, v.Model
                FROM Repairs r
                JOIN Vehicles v ON r.VehicleID = v.VehicleID
                JOIN RepairMechanics rm ON r.RepairID = rm.RepairID
                JOIN Mechanics m ON rm.MechanicID = m.MechanicID
                WHERE m.FirstName = @firstName AND m.LastName = @lastName";
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@firstName", firstName);
                    cmd.Parameters.AddWithValue("@lastName", lastName);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Console.WriteLine($"Repair ID: {reader["RepairID"]}, " +
                                         $"Car: {reader["Brand"]} {reader["Model"]}, " +
                                         $"Date In: {reader["DateIn"]}, " +
                                         $"Date Out: {reader["DateOut"]}, " +
                                         $"Total Cost: {reader["TotalCost"]} BGN, " +
                                         $"Repair Type: {reader["RepairType"]}");
                        }
                    }
                }
            }
                
        }
        public void AllVehiclesInServiceNow(SqlConnection connection)
        {
            using (connection = new SqlConnection(@"Data Source=DESKTOP-LT689HU\SQLEXPRESS;" +
            "Integrated Security=True;Trust Server Certificate=True;" +
            "Initial Catalog=CarService;"))
            {
                connection.Open();

                string query = @"
                SELECT v.Brand, v.Model, v.LicensePlate, r.DateIn
                FROM Vehicles v
                JOIN Repairs r ON v.VehicleID = r.VehicleID
                WHERE r.DateOut > GETDATE()";
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Console.WriteLine($"Brand: {reader["Brand"]}, " +
                                         $"Model: {reader["Model"]}, " +
                                         $"License Plate: {reader["LicensePlate"]}, " +
                                         $"Date in: {reader["DateIn"]}");
                        }
                    }
                }
            }
        }
        public void TotalRepairCostForVehicle(SqlConnection connection)
        {
            using (connection = new SqlConnection(@"Data Source=DESKTOP-LT689HU\SQLEXPRESS;" +
            "Integrated Security=True;Trust Server Certificate=True;" +
            "Initial Catalog=CarService;"))
            {
                connection.Open();

                Console.WriteLine("Enter the vehicle license plate: ");
                string licensePlate = Console.ReadLine();

                string query = @"
                SELECT v.Brand, v.Model, v.LicensePlate, SUM(r.TotalCost) AS TotalRepairCost
                FROM Vehicles v
                JOIN Repairs r ON v.VehicleID = r.VehicleID
                WHERE v.LicensePlate = @licensePlate
                GROUP BY v.Brand, v.Model, v.LicensePlate;";
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@licensePlate", licensePlate);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Console.WriteLine($"Total repairs cost: {reader["TotalRepairCost"]}");
                        }
                    }
                }
            }
        }
        public void MechanicWithTheMostRepairs(SqlConnection connection)
        {
            using (connection = new SqlConnection(@"Data Source=DESKTOP-LT689HU\SQLEXPRESS;" +
            "Integrated Security=True;Trust Server Certificate=True;" +
            "Initial Catalog=CarService;"))
            {

                connection.Open();

                string query = @"
                SELECT TOP 1 m.FirstName, m.LastName, COUNT(rm.RepairID) AS RepairsCount
                FROM Mechanics m
                JOIN RepairMechanics rm ON m.MechanicID = rm.MechanicID
                GROUP BY m.FirstName, m.LastName
                ORDER BY RepairsCount DESC";
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Console.WriteLine($"Mechanics with the most repairs: {reader["FirstName"]} {reader["LastName"]}");
                        }
                    }
                }
            }
        }
        public void RepairCountByMonth(SqlConnection connection)
        {
            using (connection = new SqlConnection(@"Data Source=DESKTOP-LT689HU\SQLEXPRESS;" +
            "Integrated Security=True;Trust Server Certificate=True;" +
            "Initial Catalog=CarService;"))
            {
                connection.Open();

                string query = @"
                SELECT MONTH(DateIn) AS RepairMonth, COUNT(*) AS RepairCount
                FROM Repairs
                GROUP BY MONTH(DateIn)
                ORDER BY RepairMonth";
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Console.WriteLine($"Month: {reader["RepairMonth"]}, Repairs: {reader["RepairCount"]}");
                        }
                    }
                }
            }
        }
        public void VehiclesInRepairByDate(SqlConnection connection)
        {
            using (connection = new SqlConnection(@"Data Source=DESKTOP-LT689HU\SQLEXPRESS;" +
            "Integrated Security=True;Trust Server Certificate=True;" +
            "Initial Catalog=CarService;"))
            {
                connection.Open();

                Console.WriteLine("Enter the date: ");
                DateTime date = DateTime.Parse(Console.ReadLine());
                string query = @"
                SELECT v.LicensePlate, v.Brand, v.Model, r.RepairID, r.RepairType, r.TotalCost
                FROM Repairs r
                JOIN Vehicles v ON r.VehicleID = v.VehicleID
                WHERE r.DateIn = @date;";
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@date", date);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Console.WriteLine($"License Plate: {reader["LicensePlate"]}, " +
                                          $"Brand: {reader["Brand"]}, Model: {reader["Model"]}, " +
                                          $"Repair ID: {reader["RepairID"]}, Repair Type: {reader["RepairType"]}, " +
                                          $"Total Cost: {reader["TotalCost"]} BGN");
                        }
                    }
                }
            }
        }
        public void TotalIncomeForYear(SqlConnection connection)
        {
            using (connection = new SqlConnection(@"Data Source=DESKTOP-LT689HU\SQLEXPRESS;" +
            "Integrated Security=True;Trust Server Certificate=True;" +
            "Initial Catalog=CarService;"))
            {
                connection.Open();

                Console.WriteLine("Enter the year: ");
                int year = int.Parse(Console.ReadLine());
                string query = @"
                SELECT SUM(TotalCost) AS TotalIncome
                FROM Repairs
                WHERE YEAR(DateOut)=@year";
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@year", year);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Console.WriteLine($"Total income for year {year} - {reader["TotalIncome"]} BGN");
                        }
                    }
                }
            }
        }
    }
}
