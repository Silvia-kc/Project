﻿using Microsoft.Data.SqlClient;
using Microsoft.Identity.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Markup;

namespace CarService_Project
{
    public class InsertRequest
    {
        public void InsertClients(SqlConnection connection)
        {
            using (connection=new SqlConnection(@"Data Source=DESKTOP-LT689HU\SQLEXPRESS;" +
            "Integrated Security=True;Trust Server Certificate=True;" +
            "Initial Catalog=CarService;"))
            {
                connection.Open();

                Console.WriteLine("Enter client first name: ");
                string firstName = Console.ReadLine();

                Console.WriteLine("Enter client last name: ");
                string lastName = Console.ReadLine();

                Console.WriteLine("Enter client phone: ");
                string phoneNumber = Console.ReadLine();

                Console.WriteLine("Enter client email: ");
                string email = Console.ReadLine();

                string insertClientsQuery = @"INSERT INTO Clients (FirstName, LastName, PhoneNumber, Email)
                VALUES (@firstName, @lastName, @phoneNumber, @email)";

                using (SqlCommand cmd = new SqlCommand(insertClientsQuery, connection))
                {
                    cmd.Parameters.AddWithValue("@firstName", firstName);
                    cmd.Parameters.AddWithValue("@lastName", lastName);
                    cmd.Parameters.AddWithValue("@phoneNumber", phoneNumber);
                    cmd.Parameters.AddWithValue("@email", email);
                    cmd.ExecuteNonQuery();
                }
            }
        }
        public void InsertVehicles(SqlConnection connection)
        {
            using (connection=new SqlConnection(@"Data Source=DESKTOP-LT689HU\SQLEXPRESS;" +
            "Integrated Security=True;Trust Server Certificate=True;" +
            "Initial Catalog=CarService;"))
            {
                connection.Open();

                Console.WriteLine("Enter vehicle brand: ");
                string brand = Console.ReadLine();

                Console.WriteLine("Enter vehicle model: ");
                string model = Console.ReadLine();

                Console.WriteLine("Enter vehicle year of manifacture: ");
                int yearOfManifacture = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter vehicle license plate: ");
                string licensePlate = Console.ReadLine();

                Console.WriteLine("Enter client id: ");
                int clientId = int.Parse(Console.ReadLine());

                string insertVehiclesQuery = @"INSERT INTO Vehicles (Brand, Model, YearOfManifacture, LicensePlate, ClientID)
                VALUES(@brand, @model, @yearOfManifacture, @licensePlate, @clientId)";
                using (SqlCommand cmd = new SqlCommand(insertVehiclesQuery, connection))
                {
                    cmd.Parameters.AddWithValue("@brand", brand);
                    cmd.Parameters.AddWithValue("@model", model);
                    cmd.Parameters.AddWithValue("@yearOfManifacture", yearOfManifacture);
                    cmd.Parameters.AddWithValue("@licensePlate", licensePlate);
                    cmd.Parameters.AddWithValue("@clientId", clientId);
                    cmd.ExecuteNonQuery();
                }
            }
        }
        public void InsertRepairs(SqlConnection connection)
        {
            using(connection=new SqlConnection(@"Data Source=DESKTOP-LT689HU\SQLEXPRESS;" +
            "Integrated Security=True;Trust Server Certificate=True;" +
            "Initial Catalog=CarService;"))
            {
                connection.Open();

                Console.WriteLine("Enter the date it comes in for repair: ");
                DateTime dateIn= DateTime.Parse(Console.ReadLine());

                Console.WriteLine("Enter the date the car is ready: ");
                DateTime dateOut=DateTime.Parse(Console.ReadLine());

                Console.WriteLine("Enter the total cost of repair: ");
                double totalCost=double.Parse(Console.ReadLine());

                Console.WriteLine("Enter repair type: ");
                string repairType=Console.ReadLine();

                Console.WriteLine("Enter vehicle id: ");
                int vehicleId=int.Parse(Console.ReadLine());

                string insertRepairsQuery = @"INSERT INTO Repairs (DateIn, DateOut, TotalCost, RepairType, VehicleID)
                VALUES(@dateIn, @dateOut, @totalCost, @repairType, @vehicleId)";
                using (SqlCommand cmd = new SqlCommand(insertRepairsQuery, connection))
                {
                    cmd.Parameters.AddWithValue("@dateIn", dateIn);
                    cmd.Parameters.AddWithValue("@dateOut", dateOut);
                    cmd.Parameters.AddWithValue("@totalCost", totalCost);
                    cmd.Parameters.AddWithValue("@repairType", repairType);
                    cmd.Parameters.AddWithValue("@vehicleId",vehicleId);
                    cmd.ExecuteNonQuery();
                }
            }
        }
        public void InsertMechanics(SqlConnection connection)
        {
            using(connection=new SqlConnection(@"Data Source=DESKTOP-LT689HU\SQLEXPRESS;" +
            "Integrated Security=True;Trust Server Certificate=True;" +
            "Initial Catalog=CarService;"))
            {
                connection.Open();

                Console.WriteLine("Enter mechanic first name: ");
                string firstName = Console.ReadLine();

                Console.WriteLine("Enter mechanic last name: ");
                string lastName = Console.ReadLine();

                Console.WriteLine("Enter mechanic specialization: ");
                string specialization=Console.ReadLine();

                string insertMechanicsQuery = @"INSERT INTO Mechanics (FirstName, LastName, Specialization)
                VALUES (@firstName, @lastName, @specialization)";
                using (SqlCommand cmd=new SqlCommand(insertMechanicsQuery,connection))
                {
                    cmd.Parameters.AddWithValue("@firstName", firstName);
                    cmd.Parameters.AddWithValue("@lastName", lastName);
                    cmd.Parameters.AddWithValue("@specialization", specialization);
                    cmd.ExecuteNonQuery();
                }
            }
        }
        public void InsertRepairMechanics(SqlConnection connection)
        {
            using (connection=new SqlConnection(@"Data Source=DESKTOP-LT689HU\SQLEXPRESS;" +
            "Integrated Security=True;Trust Server Certificate=True;" +
            "Initial Catalog=CarService;"))
            {
                connection.Open();

                Console.WriteLine("Enter repair id: ");
                int repairId=int.Parse(Console.ReadLine());

                Console.WriteLine("Enter mechanic id: ");
                int mechanicId=int.Parse(Console.ReadLine());

                Console.WriteLine("Enter working hours: ");
                int workingHours=int.Parse(Console.ReadLine());

                string InsertReapirMechanicsQuery = @"INSERT INTO RepairMechanics (RepairID, MechanicID, WorkingHours)
                VALUES (@repairId, @mechanicId, @workingHours)";
                using (SqlCommand cmd=new SqlCommand(InsertReapirMechanicsQuery,connection))
                {
                    cmd.Parameters.AddWithValue(@"repairId", repairId);
                    cmd.Parameters.AddWithValue("@mechanicId", mechanicId);
                    cmd.Parameters.AddWithValue("@workingHours", workingHours);
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}
