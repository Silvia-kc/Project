﻿// See https://aka.ms/new-console-template for more information
using Azure;
using CarService_Project;
using Microsoft.Data.SqlClient;
using System.Threading.Channels;
SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-LT689HU\SQLEXPRESS;" +
            "Integrated Security=True;Trust Server Certificate=True;" +
            "Initial Catalog=CarService;");

Console.WriteLine("1.Insert in table Clients.");
Console.WriteLine("2.Insert in table Vehicles");
Console.WriteLine("3.Insert in table Repairs.");
Console.WriteLine("4.Insert in table Mechanics.");
Console.WriteLine("5.Insert in table RepairMechanics.");
Console.WriteLine("6.Request - Get all clients and vehicles.");
Console.WriteLine("7.Request - Search vehicles by license plate.");
Console.WriteLine("8.Request - All repairs about certain client.");
Console.WriteLine("9.Request - Get repairs by mechanic.");
Console.WriteLine("10.Request - All vehicles in service now.");
Console.WriteLine("11.Request - Total repair cost for vehicle.");
Console.WriteLine("12.Request - Mechanic with the most repairs.");
Console.WriteLine("13.Request - Repair count by month.");
Console.WriteLine("14.Request - Vehicles in repair by date.");
Console.WriteLine("15.Request - Total income for year.");

InsertRequest insertRequest= new InsertRequest();
SelectRequest selectRequest= new SelectRequest();
string input=Console.ReadLine();
while(input!="END")
{
    if (input == "1")
    {
        insertRequest.InsertClients(connection);
    }
    else if (input == "2")
    {
        insertRequest.InsertVehicles(connection);
    }
    else if (input == "3")
    {
        insertRequest.InsertRepairs(connection);
    }
    else if (input == "4")
    {
        insertRequest.InsertMechanics(connection);
    }
    else if (input == "5")
    {
        insertRequest.InsertRepairMechanics(connection);
    }
    else if (input == "6")
    {
        selectRequest.GetAllClientsAndVehicles(connection);
    }
    else if (input == "7")
    {
        selectRequest.SearchVehiclesByLicensePlate(connection);
    }
    else if (input == "8")
    {
        selectRequest.AllRepairsAboutCertainClient(connection);
    }
    else if (input == "9")
    {
        selectRequest.GetRepairsByMechanic(connection);
    }
    else if (input == "10")
    {
        selectRequest.AllVehiclesInServiceNow(connection);
    }
    else if (input == "11")
    { 
        selectRequest.TotalRepairCostForVehicle(connection);
    }
    else if(input == "12")
    {
        selectRequest.MechanicWithTheMostRepairs(connection);
    }
    else if(input == "13")
    {
        selectRequest.RepairCountByMonth(connection);
    }
    else if(input == "14")
    {
        selectRequest.VehiclesInRepairByDate(connection);
    }
    else if(input == "15")
    {
        selectRequest.TotalIncomeForYear(connection);
    }
    else
    {
        Console.WriteLine("Invalid option.");
    }
    input=Console.ReadLine();
}
